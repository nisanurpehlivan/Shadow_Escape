package com.example.shadowescape;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView title = findViewById(R.id.splashTitle);
        TextView subtitle = findViewById(R.id.splashSubtitle);
        TextView icon = findViewById(R.id.splashIcon);

        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(2000);
        fadeIn.setFillAfter(true);
        icon.startAnimation(fadeIn);
        title.startAnimation(fadeIn);

        AlphaAnimation fadeIn2 = new AlphaAnimation(0.0f, 1.0f);
        fadeIn2.setDuration(2000);
        fadeIn2.setStartOffset(800);
        fadeIn2.setFillAfter(true);
        subtitle.startAnimation(fadeIn2);

        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }, 3500);
    }
}
