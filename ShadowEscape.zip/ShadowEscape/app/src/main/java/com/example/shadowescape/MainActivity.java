package com.example.shadowescape;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnStart = findViewById(R.id.btnStart);
        Button btnHowToPlay = findViewById(R.id.btnHowToPlay);

        btnStart.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Room1Activity.class);
            intent.putExtra("startTime", System.currentTimeMillis());
            intent.putExtra("totalHints", 0);
            startActivity(intent);
            finish();
        });

        btnHowToPlay.setOnClickListener(v ->
            startActivity(new Intent(MainActivity.this, HowToPlayActivity.class))
        );
    }
}
