package com.example.shadowescape;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        long totalTime = getIntent().getLongExtra("totalTime", 0);
        int totalHints = getIntent().getIntExtra("totalHints", 0);

        TextView tvStars = findViewById(R.id.tvStars);
        TextView tvTime = findViewById(R.id.tvTime);
        TextView tvHints = findViewById(R.id.tvHints);
        Button btnReplay = findViewById(R.id.btnReplay);
        Button btnExit = findViewById(R.id.btnExit);

        // Format time
        long min = totalTime / 60;
        long sec = totalTime % 60;
        tvTime.setText(String.format("⏱ Toplam Süre: %02d:%02d", min, sec));
        tvHints.setText(String.format("💡 Kullanılan İpucu: %d / 4", totalHints));

        // Calculate stars
        String stars;
        if (totalTime < 180 && totalHints == 0) {
            stars = "⭐⭐⭐"; // Under 3 min, no hints
        } else if (totalTime < 300 && totalHints <= 2) {
            stars = "⭐⭐"; // Under 5 min, max 2 hints
        } else {
            stars = "⭐"; // Completed
        }
        tvStars.setText(stars);

        btnReplay.setOnClickListener(v -> {
            Intent intent = new Intent(ResultActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        btnExit.setOnClickListener(v -> {
            finishAffinity();
        });
    }
}
