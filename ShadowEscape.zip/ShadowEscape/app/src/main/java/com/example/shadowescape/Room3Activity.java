package com.example.shadowescape;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class Room3Activity extends AppCompatActivity {

    private CheckBox cbSun, cbMoon, cbLightning, cbKey, cbSkull, cbSnake;
    private LinearLayout phase1Layout, phase2Layout;
    private Button btnCheckPhase1, btnCheckPhase2, btnHint, btnNext;
    private EditText etPassword;
    private TextView tvTimer, tvClue, tvResult;
    private long startTime;
    private int totalHints;
    private boolean hintUsed = false;
    private boolean phase1Solved = false;
    private boolean solved = false;
    private Handler timerHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room3);

        startTime = getIntent().getLongExtra("startTime", System.currentTimeMillis());
        totalHints = getIntent().getIntExtra("totalHints", 0);

        cbSun = findViewById(R.id.cbSun);
        cbMoon = findViewById(R.id.cbMoon);
        cbLightning = findViewById(R.id.cbLightning);
        cbKey = findViewById(R.id.cbKey);
        cbSkull = findViewById(R.id.cbSkull);
        cbSnake = findViewById(R.id.cbSnake);

        phase1Layout = findViewById(R.id.phase1Layout);
        phase2Layout = findViewById(R.id.phase2Layout);
        btnCheckPhase1 = findViewById(R.id.btnCheckPhase1);
        btnCheckPhase2 = findViewById(R.id.btnCheckPhase2);
        btnHint = findViewById(R.id.btnHint);
        btnNext = findViewById(R.id.btnNext);
        etPassword = findViewById(R.id.etPassword);
        tvTimer = findViewById(R.id.tvTimer);
        tvClue = findViewById(R.id.tvClue);
        tvResult = findViewById(R.id.tvResult);

        btnNext.setVisibility(View.GONE);
        startTimer();

        btnCheckPhase1.setOnClickListener(v -> checkPhase1());
        btnCheckPhase2.setOnClickListener(v -> checkPhase2());
        btnHint.setOnClickListener(v -> showHint());
        btnNext.setOnClickListener(v -> goToNextRoom());
    }

    private void startTimer() {
        timerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                long elapsed = (System.currentTimeMillis() - startTime) / 1000;
                long min = elapsed / 60;
                long sec = elapsed % 60;
                tvTimer.setText(String.format("⏱ %02d:%02d", min, sec));
                timerHandler.postDelayed(this, 1000);
            }
        }, 0);
    }

    private void checkPhase1() {
        if (phase1Solved) return;

        boolean sun = cbSun.isChecked();
        boolean moon = cbMoon.isChecked();
        boolean lightning = cbLightning.isChecked();
        boolean key = cbKey.isChecked();
        boolean skull = cbSkull.isChecked();
        boolean snake = cbSnake.isChecked();

        // Correct: Sun, Moon, Lightning (sky symbols only)
        if (sun && moon && lightning && !key && !skull && !snake) {
            phase1Solved = true;
            tvResult.setText("✅ Doğru semboller! Şifre tablosu ortaya çıktı!");
            tvResult.setTextColor(0xFF4CAF50);

            // Disable checkboxes
            cbSun.setEnabled(false);
            cbMoon.setEnabled(false);
            cbLightning.setEnabled(false);
            cbKey.setEnabled(false);
            cbSkull.setEnabled(false);
            cbSnake.setEnabled(false);

            // Show phase 2
            btnCheckPhase1.setVisibility(View.GONE);
            phase2Layout.setVisibility(View.VISIBLE);
            btnCheckPhase2.setVisibility(View.VISIBLE);
            tvClue.setText(getString(R.string.room3_clue2));
            tvResult.setText("");
        } else if (skull || snake) {
            tvResult.setText("💀 Tuzağa düştün! Karanlık semboller seçilmemeli!");
            tvResult.setTextColor(0xFFF44336);
        } else {
            tvResult.setText("❌ Eksik veya yanlış seçim. Gökyüzüne bak!");
            tvResult.setTextColor(0xFFF44336);
        }
    }

    private void checkPhase2() {
        if (solved) return;

        // Use US locale to ensure 'i' becomes 'I' for "ISIK"
        String password = etPassword.getText().toString().trim().toUpperCase(Locale.US);

        // Cipher: ☀️→I, 🌙→S, ⚡→I, ★→K → ISIK
        if (password.equals("ISIK")) {
            solved = true;
            tvResult.setText("✅ Şifre doğru! Antik kapı gıcırdayarak açıldı!");
            tvResult.setTextColor(0xFF4CAF50);
            btnNext.setVisibility(View.VISIBLE);
            btnCheckPhase2.setEnabled(false);
            btnCheckPhase2.setAlpha(0.5f);
            etPassword.setEnabled(false);
        } else {
            tvResult.setText("❌ Yanlış şifre! Sembolleri tekrar çöz.");
            tvResult.setTextColor(0xFFF44336);
        }
    }

    private void showHint() {
        if (!hintUsed) {
            hintUsed = true;
            totalHints++;
            if (!phase1Solved) {
                tvResult.setText("💡 İpucu: Gökyüzünde ne görürsün? Güneş, Ay, Şimşek...");
                tvResult.setTextColor(0xFF00BCD4);
            } else {
                tvResult.setText("💡 İpucu: Her sembol bir harfe karşılık gelir. Tabloyu dikkatlice oku.");
                tvResult.setTextColor(0xFF00BCD4);
            }
            btnHint.setEnabled(false);
            btnHint.setText("💡 Kullanıldı");
            btnHint.setAlpha(0.5f);
        }
    }

    private void goToNextRoom() {
        Intent intent = new Intent(this, Room4Activity.class);
        intent.putExtra("startTime", startTime);
        intent.putExtra("totalHints", totalHints);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacksAndMessages(null);
    }
}
