package com.example.shadowescape;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class Room1Activity extends AppCompatActivity {

    private Spinner spinner1, spinner2, spinner3, spinner4;
    private TextView tvTimer, tvClue, tvResult;
    private Button btnCheck, btnHint, btnNext;
    private long startTime;
    private int totalHints;
    private boolean hintUsed = false;
    private boolean solved = false;
    private Handler timerHandler = new Handler();

    private String[] books = {"-- Seç --", "🐉 Ejderha", "🌙 Ay", "☀️ Güneş", "⭐ Yıldız"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room1);

        startTime = getIntent().getLongExtra("startTime", System.currentTimeMillis());
        totalHints = getIntent().getIntExtra("totalHints", 0);

        spinner1 = findViewById(R.id.spinner1);
        spinner2 = findViewById(R.id.spinner2);
        spinner3 = findViewById(R.id.spinner3);
        spinner4 = findViewById(R.id.spinner4);
        tvTimer = findViewById(R.id.tvTimer);
        tvClue = findViewById(R.id.tvClue);
        tvResult = findViewById(R.id.tvResult);
        btnCheck = findViewById(R.id.btnCheck);
        btnHint = findViewById(R.id.btnHint);
        btnNext = findViewById(R.id.btnNext);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, books);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner2.setAdapter(adapter);
        spinner3.setAdapter(adapter);
        spinner4.setAdapter(adapter);

        btnNext.setVisibility(View.GONE);
        startTimer();

        btnCheck.setOnClickListener(v -> checkAnswer());
        btnHint.setOnClickListener(v -> showHint());
        btnNext.setOnClickListener(v -> goToNextRoom());
    }

    private void startTimer() {
        timerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                long elapsed = (System.currentTimeMillis() - startTime) / 1000;
                long min = elapsed / 60;
                long sec = elapsed % 60;
                tvTimer.setText(String.format("⏱ %02d:%02d", min, sec));
                timerHandler.postDelayed(this, 1000);
            }
        }, 0);
    }

    private void checkAnswer() {
        if (solved) return;

        int s1 = spinner1.getSelectedItemPosition();
        int s2 = spinner2.getSelectedItemPosition();
        int s3 = spinner3.getSelectedItemPosition();
        int s4 = spinner4.getSelectedItemPosition();

        if (s1 == 0 || s2 == 0 || s3 == 0 || s4 == 0) {
            tvResult.setText("⚠️ Tüm rafları doldur!");
            tvResult.setTextColor(0xFFFF9800);
            return;
        }

        // Correct: Ejderha(1), Ay(2), Güneş(3), Yıldız(4)
        if (s1 == 1 && s2 == 2 && s3 == 3 && s4 == 4) {
            solved = true;
            tvResult.setText("✅ Doğru! Kütüphanenin kapısı açıldı!");
            tvResult.setTextColor(0xFF4CAF50);
            btnNext.setVisibility(View.VISIBLE);
            btnCheck.setEnabled(false);
            btnCheck.setAlpha(0.5f);
        } else {
            tvResult.setText("❌ Yanlış sıra! İpucunu tekrar oku.");
            tvResult.setTextColor(0xFFF44336);
        }
    }

    private void showHint() {
        if (!hintUsed) {
            hintUsed = true;
            totalHints++;
            tvClue.setText(tvClue.getText() + "\n\n💡 İpucu: İlk sırada gecenin yaratığını ara...\nSon sırada gökyüzünde parlayanı koy.");
            btnHint.setEnabled(false);
            btnHint.setText("💡 Kullanıldı");
            btnHint.setAlpha(0.5f);
        }
    }

    private void goToNextRoom() {
        Intent intent = new Intent(this, Room2Activity.class);
        intent.putExtra("startTime", startTime);
        intent.putExtra("totalHints", totalHints);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacksAndMessages(null);
    }
}
