package com.example.shadowescape;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class Room4Activity extends AppCompatActivity {

    private Spinner spinnerNumber;
    private Switch switchBlue, switchRed;
    private EditText etFinalPassword;
    private TextView tvTimer, tvClue, tvResult;
    private Button btnCheck, btnHint, btnFinish;
    private long startTime;
    private int totalHints;
    private boolean hintUsed = false;
    private boolean solved = false;
    private Handler timerHandler = new Handler();

    private String[] numbers = {"-- Seç --", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room4);

        startTime = getIntent().getLongExtra("startTime", System.currentTimeMillis());
        totalHints = getIntent().getIntExtra("totalHints", 0);

        spinnerNumber = findViewById(R.id.spinnerNumber);
        switchBlue = findViewById(R.id.switchBlue);
        switchRed = findViewById(R.id.switchRed);
        etFinalPassword = findViewById(R.id.etFinalPassword);
        tvTimer = findViewById(R.id.tvTimer);
        tvClue = findViewById(R.id.tvClue);
        tvResult = findViewById(R.id.tvResult);
        btnCheck = findViewById(R.id.btnCheck);
        btnHint = findViewById(R.id.btnHint);
        btnFinish = findViewById(R.id.btnFinish);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, numbers);
        spinnerNumber.setAdapter(adapter);

        btnFinish.setVisibility(View.GONE);
        startTimer();

        btnCheck.setOnClickListener(v -> checkAnswer());
        btnHint.setOnClickListener(v -> showHint());
        btnFinish.setOnClickListener(v -> goToResult());
    }

    private void startTimer() {
        timerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                long elapsed = (System.currentTimeMillis() - startTime) / 1000;
                long min = elapsed / 60;
                long sec = elapsed % 60;
                tvTimer.setText(String.format("⏱ %02d:%02d", min, sec));
                timerHandler.postDelayed(this, 1000);
            }
        }, 0);
    }

    private void checkAnswer() {
        if (solved) return;

        int selectedNumber = spinnerNumber.getSelectedItemPosition(); // 4 = "4"
        boolean blue = switchBlue.isChecked();
        boolean red = switchRed.isChecked();
        // Use US locale to ensure 'i' becomes 'I' for "ISIK"
        String password = etFinalPassword.getText().toString().trim().toUpperCase(Locale.US);

        StringBuilder errors = new StringBuilder();

        if (selectedNumber == 0) {
            errors.append("⚠️ Kitap sayısını seç!\n");
        } else if (selectedNumber != 4) {
            errors.append("❌ Kitap sayısı yanlış!\n");
        }

        if (!blue) {
            errors.append("❌ Mavi anahtar doğru değil!\n");
        }

        if (red) {
            errors.append("❌ Kırmızı anahtar doğru değil!\n");
        }

        if (password.isEmpty()) {
            errors.append("⚠️ Şifreyi gir!\n");
        } else if (!password.equals("ISIK")) {
            errors.append("❌ Şifre yanlış!\n");
        }

        // All correct: number=4, blue=ON, red=OFF, password=ISIK
        if (selectedNumber == 4 && blue && !red && password.equals("ISIK")) {
            solved = true;
            tvResult.setText("🎉 KAPISI AÇILDI! Özgürsün!");
            tvResult.setTextColor(0xFFFFD700);
            btnFinish.setVisibility(View.VISIBLE);
            btnCheck.setEnabled(false);
            btnCheck.setAlpha(0.5f);

            // Change background color to indicate success
            findViewById(android.R.id.content).setBackgroundColor(0xFF0D1A00);
        } else {
            tvResult.setText(errors.toString().trim());
            tvResult.setTextColor(0xFFF44336);
        }
    }

    private void showHint() {
        if (!hintUsed) {
            hintUsed = true;
            totalHints++;
            tvClue.setText(tvClue.getText() + "\n\n💡 İpucu:\n• Kütüphanede 4 kitap vardı\n• Mavi doğruydu, kırmızı yanlış\n• Tapınaktaki şifre: Sembollerin harfleri");
            btnHint.setEnabled(false);
            btnHint.setText("💡 Kullanıldı");
            btnHint.setAlpha(0.5f);
        }
    }

    private void goToResult() {
        long endTime = System.currentTimeMillis();
        long totalTime = (endTime - startTime) / 1000;

        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("totalTime", totalTime);
        intent.putExtra("totalHints", totalHints);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacksAndMessages(null);
    }
}
