package com.example.shadowescape;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class Room2Activity extends AppCompatActivity {

    private Switch switchRed, switchBlue, switchGreen, switchYellow, switchPurple;
    private TextView tvTimer, tvClue, tvResult;
    private Button btnCheck, btnHint, btnNext;
    private long startTime;
    private int totalHints;
    private boolean hintUsed = false;
    private boolean solved = false;
    private Handler timerHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room2);

        startTime = getIntent().getLongExtra("startTime", System.currentTimeMillis());
        totalHints = getIntent().getIntExtra("totalHints", 0);

        switchRed = findViewById(R.id.switchRed);
        switchBlue = findViewById(R.id.switchBlue);
        switchGreen = findViewById(R.id.switchGreen);
        switchYellow = findViewById(R.id.switchYellow);
        switchPurple = findViewById(R.id.switchPurple);
        tvTimer = findViewById(R.id.tvTimer);
        tvClue = findViewById(R.id.tvClue);
        tvResult = findViewById(R.id.tvResult);
        btnCheck = findViewById(R.id.btnCheck);
        btnHint = findViewById(R.id.btnHint);
        btnNext = findViewById(R.id.btnNext);

        btnNext.setVisibility(View.GONE);
        startTimer();

        btnCheck.setOnClickListener(v -> checkAnswer());
        btnHint.setOnClickListener(v -> showHint());
        btnNext.setOnClickListener(v -> goToNextRoom());
    }

    private void startTimer() {
        timerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                long elapsed = (System.currentTimeMillis() - startTime) / 1000;
                long min = elapsed / 60;
                long sec = elapsed % 60;
                tvTimer.setText(String.format("⏱ %02d:%02d", min, sec));
                timerHandler.postDelayed(this, 1000);
            }
        }, 0);
    }

    private void checkAnswer() {
        if (solved) return;

        boolean red = switchRed.isChecked();
        boolean blue = switchBlue.isChecked();
        boolean green = switchGreen.isChecked();
        boolean yellow = switchYellow.isChecked();
        boolean purple = switchPurple.isChecked();

        // Correct: only Blue and Green ON
        if (!red && blue && green && !yellow && !purple) {
            solved = true;
            tvResult.setText("✅ Doğru karışım! Yeşil bir duman yükseldi ve kapı açıldı!");
            tvResult.setTextColor(0xFF4CAF50);
            btnNext.setVisibility(View.VISIBLE);
            btnCheck.setEnabled(false);
            btnCheck.setAlpha(0.5f);
        } else {
            tvResult.setText("❌ Kazan patladı! Yanlış karışım. Tekrar dene.");
            tvResult.setTextColor(0xFFF44336);
        }
    }

    private void showHint() {
        if (!hintUsed) {
            hintUsed = true;
            totalHints++;
            tvClue.setText(tvClue.getText() + "\n\n💡 İpucu: Gökyüzü mavi, orman yeşildir.\nSadece bu ikisini aç.");
            btnHint.setEnabled(false);
            btnHint.setText("💡 Kullanıldı");
            btnHint.setAlpha(0.5f);
        }
    }

    private void goToNextRoom() {
        Intent intent = new Intent(this, Room3Activity.class);
        intent.putExtra("startTime", startTime);
        intent.putExtra("totalHints", totalHints);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacksAndMessages(null);
    }
}
