# 🏰 Shadow Escape

Kendi geliştirdiğim bu mobil oyun, oyuncuyu gizemli bir antik tapınağın içine bırakıyor. Amacımız basit ama zorlayıcı: Odalardaki bulmacaları çözüp sağ salim dışarı çıkmak.

## 🕹️ Oyun Hakkında
Bu proje benim için hem mantık kurgusu hem de Android arayüzü üzerine güzel bir çalışma oldu. Oyunda toplamda **4 farklı oda** bulunuyor:

1.  **Kütüphane:** Etraftaki ipuçlarını birleştirip doğru sayıyı bulman gerekiyor.
2.  **Laboratuvar:** İksirler ve renklerin dünyasında doğru kombinasyonu yapmalısın.
3.  **Şifre Odası:** Gökyüzü sembollerini analiz edip kadim şifreyi (**ISIK**) çözmen gereken yer.
4.  **Son Kapı:** Burası final. Önceki odalarda öğrendiğin her şeyi burada kullanman gerekiyor.

## 🛠️ Neler Kullandım?
*   Tamamen **Java** ile geliştirdim.
*   Tasarımları XML üzerinden, oyunun karanlık ve antik havasına uygun olacak şekilde (Gold & Dark temasıyla) hazırladım.
*   Zamanlayıcı ve ipucu sistemleri ekleyerek oyunun rekabet dozunu artırmaya çalıştım.

## 🚀 Nasıl Çalıştırılır?
Projeyi klonladıktan sonra Android Studio ile açıp direkt çalıştırabilirsiniz. Minimum SDK olarak API 24 (Android 7.0) kullandım, yani çoğu cihazda sorunsuz çalışacaktır.

---
**Not:** Şifreler ve bulmacalar bazen kafa karıştırıcı olabilir, ipuçlarını kullanmaktan çekinmeyin! 😉
